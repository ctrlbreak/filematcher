# File Matcher 1.0.0 - Installation

## Quick Start

1. **No installation required** - this is a standalone Python script
2. **Requirements**: Python 3.6 or higher
3. **Usage**: python3 file_matcher.py <dir1> <dir2> [options]

## Running Tests

To verify the installation:
```bash
python3 run_tests.py
```

## Examples

Compare two directories:
```bash
python3 file_matcher.py test_dir1 test_dir2
```

Use fast mode for large files:
```bash
python3 file_matcher.py test_dir1 test_dir2 --fast
```

Get summary only:
```bash
python3 file_matcher.py test_dir1 test_dir2 --summary
```

## Features

- File matching using content hashing (MD5/SHA-256)
- Fast mode for large files (>100MB)
- Summary and detailed output modes
- Cross-platform compatibility
- No external dependencies

For more information, see README.md
