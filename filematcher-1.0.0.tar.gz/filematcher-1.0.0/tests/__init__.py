"""
Tests for file_matcher.py functionality.
""" 